package ch06.sec08.exam04;

public class Calculator {

    public double areaRectangle(int x) {
        return x*x;
    }

    public double areaRectangle(int x, int y) {
        return x * y;
    }

}
