package ch06.sec07.exam01;

public class Car {

    String model;
    String color;
    int speed;

    public Car() {
    }

    public Car(String model, String color, int speed) {
        this.model = model;
        this.color = color;
        this.speed = speed;
    }
}
