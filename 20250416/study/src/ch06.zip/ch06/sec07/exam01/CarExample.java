package ch06.sec07.exam01;

public class CarExample {
    public static void main(String[] args) {

        Car mayCar = new Car("그랜저","검정",250);

    }
}
