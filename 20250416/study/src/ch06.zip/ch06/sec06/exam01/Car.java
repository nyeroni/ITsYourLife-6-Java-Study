package ch06.sec06.exam01;

//1.다음과 같이 Car 클래스를 정의한 경우, 각 멤버 변수가 가지는 기본값은 무엇인가?
public class Car {
    String model; //null
    boolean start; //false
    int speed; //0
}
