package ch06.sec09;

public class CarExample {
    public static void main(String[] args) {

        Car car = new Car("택시");

        car.setSpeed(10);
        car.run();

    }
}
